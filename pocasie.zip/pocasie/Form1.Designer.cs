﻿namespace pocasie;

partial class Form1
{
    /// <summary>
    ///  Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    ///  Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
        {
            components.Dispose();
        }
        base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    ///  Required method for Designer support - do not modify
    ///  the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
        this.lblLat = new System.Windows.Forms.Label();
        this.lblLon = new System.Windows.Forms.Label();
        this.txtLat = new System.Windows.Forms.TextBox();
        this.txtLon = new System.Windows.Forms.TextBox();
        this.btnGetWeather = new System.Windows.Forms.Button();
        this.lblResult = new System.Windows.Forms.Label();
        this.SuspendLayout();
        // 
        // lblLat
        // 
        this.lblLat.AutoSize = true;
        this.lblLat.Location = new System.Drawing.Point(30, 30);
        this.lblLat.Name = "lblLat";
        this.lblLat.Size = new System.Drawing.Size(90, 15);
        this.lblLat.Text = "Zem. šírka (lat):";
        // 
        // txtLat
        // 
        this.txtLat.Location = new System.Drawing.Point(130, 27);
        this.txtLat.Name = "txtLat";
        this.txtLat.Size = new System.Drawing.Size(100, 23);
        this.txtLat.Text = "48.15";
        // 
        // lblLon
        // 
        this.lblLon.AutoSize = true;
        this.lblLon.Location = new System.Drawing.Point(30, 70);
        this.lblLon.Name = "lblLon";
        this.lblLon.Size = new System.Drawing.Size(90, 15);
        this.lblLon.Text = "Zem. dĺžka (lon):";
        // 
        // txtLon
        // 
        this.txtLon.Location = new System.Drawing.Point(130, 67);
        this.txtLon.Name = "txtLon";
        this.txtLon.Size = new System.Drawing.Size(100, 23);
        this.txtLon.Text = "17.11";
        // 
        // btnGetWeather
        // 
        this.btnGetWeather.Location = new System.Drawing.Point(30, 110);
        this.btnGetWeather.Name = "btnGetWeather";
        this.btnGetWeather.Size = new System.Drawing.Size(200, 30);
        this.btnGetWeather.Text = "Zobraziť počasie";
        this.btnGetWeather.UseVisualStyleBackColor = true;
        this.btnGetWeather.Click += new System.EventHandler(this.btnGetWeather_Click);
        // 
        // lblResult
        // 
        this.lblResult.AutoSize = true;
        this.lblResult.Location = new System.Drawing.Point(30, 160);
        this.lblResult.Name = "lblResult";
        this.lblResult.Size = new System.Drawing.Size(0, 15);
        // 
        // Form1
        // 
        this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
        this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
        this.ClientSize = new System.Drawing.Size(300, 250);
        this.Controls.Add(this.lblLat);
        this.Controls.Add(this.txtLat);
        this.Controls.Add(this.lblLon);
        this.Controls.Add(this.txtLon);
        this.Controls.Add(this.btnGetWeather);
        this.Controls.Add(this.lblResult);
        this.Name = "Form1";
        this.Text = "Počasie - met.no";
        this.ResumeLayout(false);
        this.PerformLayout();
    }

    #endregion

    private System.Windows.Forms.Label lblLat;
    private System.Windows.Forms.Label lblLon;
    private System.Windows.Forms.TextBox txtLat;
    private System.Windows.Forms.TextBox txtLon;
    private System.Windows.Forms.Button btnGetWeather;
    private System.Windows.Forms.Label lblResult;
}
