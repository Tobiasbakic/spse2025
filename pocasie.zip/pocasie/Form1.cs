namespace pocasie;

using System.Net.Http;
using System.Text.Json;

public partial class Form1 : Form
{
    private readonly HttpClient _httpClient = new HttpClient();

    public Form1()
    {
        InitializeComponent();
    }

    private async void btnGetWeather_Click(object sender, EventArgs e)
    {
        string lat = txtLat.Text.Trim();
        string lon = txtLon.Text.Trim();

        if (string.IsNullOrEmpty(lat) || string.IsNullOrEmpty(lon))
        {
            MessageBox.Show("Zadajte zemepisnú šírku a dĺžku.");
            return;
        }

        string url = $"https://api.met.no/weatherapi/locationforecast/2.0/compact?lat={lat}&lon={lon}";
        _httpClient.DefaultRequestHeaders.UserAgent.ParseAdd("WeatherApp/1.0");

        try
        {
            var response = await _httpClient.GetAsync(url);
            response.EnsureSuccessStatusCode();
            var json = await response.Content.ReadAsStringAsync();

            using var doc = JsonDocument.Parse(json);
            var timeseries = doc.RootElement.GetProperty("properties").GetProperty("timeseries");
            var first = timeseries[0];
            var details = first.GetProperty("data").GetProperty("instant").GetProperty("details");

            double temp = details.GetProperty("air_temperature").GetDouble();
            double wind = details.GetProperty("wind_speed").GetDouble();

            lblResult.Text = $"Teplota: {temp} °C\nVietor: {wind} m/s";
        }
        catch (Exception ex)
        {
            lblResult.Text = "Chyba pri načítaní údajov.";
        }
    }
}
